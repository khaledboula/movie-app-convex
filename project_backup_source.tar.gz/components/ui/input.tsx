import * as React from "react";
import { TextInput, type TextInputProps } from "react-native";
import { cn } from "./utils/cn";

type InputProps = TextInputProps;

const Input = React.forwardRef<
  React.ElementRef<typeof TextInput>,
  InputProps
>(({ className, placeholderClassName, style, ...props }, ref) => {
  return (
    <TextInput
      ref={ref}
      className={cn(
        "native:h-12 h-10 w-full rounded-md border-2 border-input bg-background px-3 text-base text-white placeholder:text-muted-foreground",
        "web:flex web:py-2 web:ring-offset-background file:border-0 file:bg-transparent file:font-medium",
        "web:focus-visible:outline-none web:focus-visible:ring-2 web:focus-visible:ring-ring web:focus-visible:ring-offset-2",
        "focus:border-primary",
        props.editable === false && "opacity-50 web:cursor-not-allowed",
        className
      )}
      placeholderClassName={cn("text-muted-foreground", placeholderClassName)}
      placeholderTextColor="#666666"
      selectionColor="#6366f1"
      underlineColorAndroid="transparent"
      style={style}
      {...props}
    />
  );
});

Input.displayName = "Input";

export { Input };
export type { InputProps };