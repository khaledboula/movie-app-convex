import React from 'react';
import { Text, View } from '@/components/ui';
import { cn } from '@/components/ui/utils/cn';
import { Image } from 'expo-image';
import { Platform } from 'react-native';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export function Logo({ className, size = 'md' }: LogoProps) {
  const sizeClasses = {
    sm: 'h-8 w-24',
    md: 'h-12 w-40',
    lg: 'h-20 w-64',
    xl: 'h-32 w-96',
  };

  const textSizes = {
    sm: 'text-xl',
    md: 'text-3xl',
    lg: 'text-5xl',
    xl: 'text-7xl',
  };

  if (Platform.OS === 'web') {
    return (
      <View className={cn("flex-row items-center", className)}>
        <Image 
          source="/logo.svg"
          contentFit="contain"
          className={cn(sizeClasses[size])}
        />
      </View>
    );
  }

  return (
    <View className={cn("flex-row items-center", className)}>
      <Text 
        className={cn(
          "text-red-600 font-black italic tracking-tighter shadow-xl shadow-red-600/40",
          textSizes[size]
        )}
        style={{
          textShadowColor: 'rgba(220, 38, 38, 0.5)',
          textShadowOffset: { width: 0, height: 0 },
          textShadowRadius: 15,
        }}
      >
        CINEVERSE+
      </Text>
    </View>
  );
}
