import React, { useEffect, useState } from 'react';
import { View, Text, Button, Pressable } from '@/components/ui';
import { Download, X, Film } from 'lucide-react-native';
import * as Animatable from 'react-native-animatable';
import { Platform } from 'react-native';

export function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (Platform.OS !== 'web') return;
    const win = (globalThis as any).window;

    const handler = (e: any) => {
      // Prevent Chrome 67 and earlier from automatically showing the prompt
      e.preventDefault();
      // Stash the event so it can be triggered later.
      setDeferredPrompt(e);
      // Show the install button
      setIsVisible(true);
    };

    if (win) {
      win.addEventListener('beforeinstallprompt', handler);

      // Check if already installed
      if (win.matchMedia && win.matchMedia('(display-mode: standalone)').matches) {
        setIsVisible(false);
      }
    }

    return () => {
      if (win) {
        win.removeEventListener('beforeinstallprompt', handler);
      }
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    
    // Show the prompt
    deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`User response to the install prompt: ${outcome}`);
    
    // We've used the prompt, and can't use it again, throw it away
    setDeferredPrompt(null);
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <Animatable.View 
      animation="bounceInUp" 
      duration={1000}
      className="absolute bottom-24 left-6 right-6 z-[100]"
    >
      <View className="bg-black/80 backdrop-blur-2xl border border-red-600/30 p-6 rounded-[32px] shadow-2xl shadow-red-600/20">
        <View className="flex-row items-center mb-4">
          <View className="w-12 h-12 bg-red-600 rounded-2xl items-center justify-center mr-4 shadow-lg shadow-red-600/40">
            <Film color="white" size={24} />
          </View>
          <View className="flex-1">
            <Text className="text-white font-black italic uppercase tracking-tighter text-lg">CineVerse+</Text>
            <Text className="text-gray-400 text-xs font-medium">Install for the best experience</Text>
          </View>
          <Pressable 
            onPress={() => setIsVisible(false)}
            className="w-8 h-8 rounded-full bg-white/5 items-center justify-center border border-white/10"
          >
            <X size={14} color="#666" />
          </Pressable>
        </View>
        
        <Text className="text-white/80 text-sm mb-6 leading-relaxed">
          Install CineVerse+ on your home screen for faster access and a full-screen cinematic experience.
        </Text>
        
        <Button 
          onPress={handleInstall}
          className="bg-red-600 h-14 rounded-2xl flex-row items-center justify-center shadow-xl shadow-red-600/30 active:scale-[0.98]"
        >
          <Download size={20} color="white" className="mr-2" />
          <Text className="text-white font-black uppercase tracking-widest">Install App</Text>
        </Button>
      </View>
    </Animatable.View>
  );
}
