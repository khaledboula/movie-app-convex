import React from "react";
import { useLocalSearchParams, useRouter } from "expo-router";
import { View, Pressable, Text } from "@/components/ui";
import { WebView } from "react-native-webview";
import { X } from "lucide-react-native";
import { Platform } from "react-native";

export default function PlayerPage() {
  const { url, title } = useLocalSearchParams();
  const router = useRouter();

  if (Platform.OS === "web") {
    return (
      <View className="flex-1 bg-black">
        <View className="absolute top-10 left-6 z-50 flex-row items-center">
          <Pressable 
            onPress={() => router.back()}
            className="w-10 h-10 rounded-full bg-white/10 items-center justify-center mr-4"
          >
            <X className="text-white w-6 h-6" />
          </Pressable>
          <Text className="text-white font-bold text-lg">{title}</Text>
        </View>
        <iframe
          src={url as string}
          style={{ width: "100%", height: "100%", border: "none" }}
          allowFullScreen
          allow="autoplay; encrypted-media; fullscreen"
        />
      </View>
    );
  }

  return (
    <View className="flex-1 bg-black">
      <View className="absolute top-12 left-6 z-50 flex-row items-center">
        <Pressable 
          onPress={() => router.back()}
          className="w-10 h-10 rounded-full bg-white/10 items-center justify-center mr-4"
        >
          <X className="text-white w-6 h-6" />
        </Pressable>
        <Text className="text-white font-bold text-lg">{title}</Text>
      </View>
      <WebView
        source={{ uri: url as string }}
        className="flex-1"
        allowsFullscreenVideo
        mediaPlaybackRequiresUserAction={false}
      />
    </View>
  );
}
